#!/bin/bash

#[ ! -f /opt/lsi/3rdpartylibs/libsysfs.so.2.0.2 ] &&  rpm -i Lib_Utils-*.noarch.rpm >/dev/null || 2>/dev/null
[ ! -f /opt/MegaRAID/MegaCli/MegaCli* ] &&  rpm -i MegaCli-*.noarch.rpm >/dev/null || 2>/dev/null

arch=`uname -m`

if  [ $arch = x86_64 ]; then
	megacli=/opt/MegaRAID/MegaCli/MegaCli64	
else
	megacli=/opt/MegaRAID/MegaCli/MegaCli
fi

$megacli -AdpAllInfo -aALL > MgAdpInfo  
$megacli -EncInfo -aALL > MgEncInfo  
$megacli -FwTermLog Dsply -aALL > MgFwLog  
$megacli -PhyErrorCounters -aALL > MgPhyErrCnt  
$megacli -PDList -aALL > MgPdList  
$megacli -LDInfo -Lall -aALL > MgLdInfo  
$megacli -LdPdInfo -aALL > MgLdPdInfo  
$megacli -AdpEventLog -GetEvents  -f MgEvtLog -aALL

mkdir raidlogs
mv Mg* raidlogs
tar czvf raidlogs.tar.gz raidlogs && rm -rf raidlogs
