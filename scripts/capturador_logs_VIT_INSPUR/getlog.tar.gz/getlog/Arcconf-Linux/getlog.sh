#!/bin/bash
CMD=`uname -m | cut -c 1-6`
if [ "$CMD" = "x86_64" ]; then
	arcconf=arcconf-x64
else
	arcconf=arcconf-x86
fi

chmod 777 $arcconf
./$arcconf savesupportarchive
tar czvf support.tar.gz -C /var/log Support
