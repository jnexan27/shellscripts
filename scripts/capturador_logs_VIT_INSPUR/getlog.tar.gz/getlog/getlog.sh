#! /bin/bash
mkdir Logs
echo "========================================================"
echo "=              Collecting system logfiles              ="
echo "========================================================"
cd Logs
mkdir syslog
cp /var/log/* syslog
cp /var/log/message* syslog
cp /var/log/mcelog* syslog
cp /var/log/cron* syslog
du /var/crash >& syslog/crash.txt
dmidecode >& systeminfo.txt
cd ..

echo "========================================================"
echo "=              Collecting BMC information              ="
echo "========================================================"
which ipmitool
if [ $? -eq 0 ]
then
modprobe ipmi_watchdog
modprobe ipmi_poweroff
modprobe ipmi_devintf
modprobe ipmi_si
modprobe ipmi_msghandler
else
cd ipmitool-1.8.11
chmod 755 ./*
./configure && make install
modprobe ipmi_watchdog
modprobe ipmi_poweroff
modprobe ipmi_devintf
modprobe ipmi_si
modprobe ipmi_msghandler
cd ..
fi
ipmitool sdr > Logs/sdr.txt
ipmitool sel list > Logs/sel.txt

echo "========================================================="
echo "=              Collecting Raid information              ="
echo "========================================================="
cd Arcconf-Linux && chmod 755 getlog.sh && ./getlog.sh && mv support* ../Logs
cd ../Megacli-Linux && chmod 755 getlog.sh && ./getlog.sh && mv raidlog* ../Logs
cd ..

echo "========================================================"
echo "=    All data has been collected, creating tar file    ="
echo "========================================================"
tar czvf Logs-$HOSTNAME-`date +%y%m%d-%H%M%S`.tar.gz Logs && rm -rf Logs
echo "===== Successfully!"
